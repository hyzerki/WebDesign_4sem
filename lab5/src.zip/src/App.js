import SignUpForm from './SignUpForm';

function App() {
  return (
    <SignUpForm/>
  );
}

export default App;
